package controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import com.yammer.metrics.Metrics;
import com.yammer.metrics.core.Metric;
import com.yammer.metrics.core.MetricName;
import com.yammer.metrics.core.MetricsRegistry;

import play.mvc.Controller;

public class ActionMetrics extends Controller {
    
    public static void index() {
        MetricsRegistry registry = Metrics.defaultRegistry();
        HashMap<String, HashMap<String, List<String>>> controllers = new HashMap<String, HashMap<String, List<String>>>();
        for (Map.Entry<String, SortedMap<MetricName, Metric>> entry : registry.groupedMetrics().entrySet()) {
            String controllerName = entry.getKey();
            SortedMap<MetricName, Metric> metricsMap = entry.getValue();
            
            HashMap<String, List<String>> metrics = new HashMap<String, List<String>>();
            for (Map.Entry<MetricName, Metric> controllerMetric: metricsMap.entrySet()) {
                List<String> values = new ArrayList<String>();
                String metricType = controllerMetric.getKey().getName();
                metrics.put(metricType, values);
            }
            controllers.put(controllerName, metrics);
        }
        render(controllers);
    }
}
